package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import PageObjects.AmazonPageObjects;
import Pages.AmazonPage;

public class ValidateProductIDStepDefinitions {

	public AmazonPage pageObject = new AmazonPage();

    @Before
	public void initialSetup() {

		System.setProperty("webdriver.edge.driver",
				"C:\\Users\\PKadam\\Downloads\\CucumberBDDCMD-main\\CucumberBDDCMD-main\\CucumberBDDCMD\\src\\test\\java\\driver\\msedgedriver.exe");

		driver = new EdgeDriver();
	}

	@After
	public void user_close_the_browser() {
		driver.quit();
	}

	@When("user navigates to amazon application")
	public void user_navigates_to_amazon_application() {
	pageObject.user_navigates_to_amazon_application();
	}

	@When("user search for a product with ASIN Number {string}")
	public void user_search_for_a_product_with_ASIN_Number(String asinNo) {
		pageObject.user_search_for_a_product_with_ASIN_Number(asinNo);
	}

	@Then("user is navigated to the product details page")
	public void user_is_navigated_to_the_product_details_page() {
		pageObject.user_is_navigated_to_the_product_details_page();
	}

	@Then("validate the product with ASIN Number displayed as {string}")
	public void validate_the_product_with_ASIN_Number_displayed_as(String expectedAsinNo) throws InterruptedException {
		Thread.sleep(5000);
		pageObject.validate_the_product_with_ASIN_Number_displayed_as(expectedAsinNo);
	}
}
