package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import steps.ValidateProductIDStepDefinitions;

import org.openqa.selenium.By;
import Components.InitialSetup;

public class AmazonPageObjects{
	//public WebDriver driver = null;
	 //public WebDriver driver=  new EdgeDriver();

//	    public AmazonPageObjects(WebDriver driver) {
//	        this.driver = driver;
//	    }

	public WebElement searchBox = InitialSetup.driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));

	public WebElement searchIcon = InitialSetup.driver.findElement(By.xpath("//input[@id='nav-search-submit-button']"));
	public WebElement resultsPage = InitialSetup.driver
			.findElement(By.xpath("//span[@class='a-size-medium-plus a-color-base a-text-bold']"));

	public WebElement firstProduct = InitialSetup.driver
			.findElement(By.xpath("//span[@class='a-size-base-plus a-color-base a-text-normal']"));
	public WebElement actualAsinNo = InitialSetup.driver.findElement(By.xpath("//th[contains(text(),'ASIN')]//following-sibling::td"));

}