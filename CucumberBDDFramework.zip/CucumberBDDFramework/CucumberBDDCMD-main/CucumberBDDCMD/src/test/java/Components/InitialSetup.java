package Components;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import PageObjects.AmazonPageObjects;

public class InitialSetup {
	public static WebDriver driver = null;
	@Before
	public static void initialSetup1() {

		System.setProperty("webdriver.edge.driver",
				"C:\\Users\\PKadam\\Downloads\\CucumberBDDCMD-main\\CucumberBDDCMD-main\\CucumberBDDCMD\\src\\test\\java\\driver\\msedgedriver.exe");

		driver = new EdgeDriver();
		// pageObject = new AmazonPageObjects(driver);
	}
}