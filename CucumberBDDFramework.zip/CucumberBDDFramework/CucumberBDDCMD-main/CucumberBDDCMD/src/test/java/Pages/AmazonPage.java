package Pages;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import PageObjects.AmazonPageObjects;
import Components.InitialSetup;

public class AmazonPage {

	AmazonPageObjects elements;
	WebDriver driver = null;
	public void user_navigates_to_amazon_application() {
		InitialSetup.driver.get("https://www.amazon.in");
		InitialSetup.driver.manage().window().maximize();
	}
	
	public void user_search_for_a_product_with_ASIN_Number(String asinNo) {
		// WebElement searchBox=
		// driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
		WebElement searchBox = driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
		WebElement searchIcon = driver.findElement(By.xpath("//input[@id='nav-search-submit-button']"));
		searchBox.sendKeys(asinNo);
		searchIcon.click();
	}
	public void user_is_navigated_to_the_product_details_page() {
		elements.resultsPage.isDisplayed();
		elements.firstProduct.click();
	}
	
	public void validate_the_product_with_ASIN_Number_displayed_as(String expectedAsinNo) throws InterruptedException {
		Thread.sleep(5000);
		List<String> newTb = new ArrayList<String>(InitialSetup.driver.getWindowHandles());
		InitialSetup.driver.switchTo().window(newTb.get(1));
		Assert.assertEquals(expectedAsinNo, elements.actualAsinNo.getText());
	}
	
	@After
	public void user_close_the_browser() {
		InitialSetup.driver.quit();
	}
}